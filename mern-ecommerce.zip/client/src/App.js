import React from 'react';

const App = () => <div>Hello from Aman kulshrestha</div>;

export default App;
